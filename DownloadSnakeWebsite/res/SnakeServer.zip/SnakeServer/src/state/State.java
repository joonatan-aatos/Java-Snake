package state;

public enum State {
	
	WaitingForPlayers,
	StartingGame,
	GameRunning
}
