import engine.Engine;

public class SnakeServer {

	public static void main(String[] args) {
		
		Engine engine = new Engine();
		engine.run();		
	}

}
