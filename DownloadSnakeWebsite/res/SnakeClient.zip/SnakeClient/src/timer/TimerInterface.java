package timer;

public interface TimerInterface {
	
	public void timerEnded(Timer t);
}
