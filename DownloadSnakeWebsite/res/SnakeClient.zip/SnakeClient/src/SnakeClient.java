import engine.Engine;

public class SnakeClient {

	public static void main(String[] args) {
		
		Engine engine = new Engine();
		
		engine.run();

	}

}
